
// Lógica principal del cotizador ECCO
console.log("ECCO Cotiza listo para usar!");
